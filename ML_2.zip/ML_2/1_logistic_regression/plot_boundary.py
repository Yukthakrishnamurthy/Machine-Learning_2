import numpy as np

def plot_boundary(X, theta, ax1):
    
    x1_min = 0.0
    x1_max = 0.0
    x2_on_x1_min = 0.0
    x2_on_x1_max = 0.0
    
    # Re-arrange the terms in the equation of the hypothesis function, and solve with respect to x2, to find its values on given values of x1
    x1_min = X[:,1].min()
    x1_max = X[:,1].max()
    x2_on_x1_min = (- theta[0] - theta[1] * x1_min)/theta[2]
    x2_on_x1_max = (- theta[0] - theta[1] * x1_max)/theta[2]
    
    x_array = np.array([x1_min, x1_max])
    y_array = np.array([x2_on_x1_min, x2_on_x1_max])
    ax1.plot(x_array, y_array, c='black', label='decision boundary')
    
    # add legend to the subplot
    ax1.legend()